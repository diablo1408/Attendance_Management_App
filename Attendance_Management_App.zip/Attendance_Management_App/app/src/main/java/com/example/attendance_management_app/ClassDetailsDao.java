package com.example.attendance_management_app;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.List;


@Dao
public interface ClassDetailsDao {
   @Query("SELECT * FROM classdetails")
 List<ClassDetails> getAll();




    @Insert
    void insert(ClassDetails... classes);

    @Delete
    void delete(ClassDetails... classDetail);

}
