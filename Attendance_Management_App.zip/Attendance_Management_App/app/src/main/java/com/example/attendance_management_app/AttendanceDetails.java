package com.example.attendance_management_app;

import androidx.room.ColumnInfo;

import java.util.ArrayList;

public class AttendanceDetails {
   @ColumnInfo(name = "lecture_Date")
  private   String lectureDate;
  @ColumnInfo(name = "section")
  private   String section;
  @ColumnInfo(name = "subject")
  private   String subject;
    private ArrayList<StudentDetails> studentList=new ArrayList<>();

    public String getLectureDate() {
        return lectureDate;
    }

    public void setLectureDate(String lectureDate) {
        this.lectureDate = lectureDate;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public ArrayList<StudentDetails> getStudentList() {
        return studentList;
    }

    public void setStudentList(ArrayList<StudentDetails> studentList) {
        this.studentList = studentList;
    }
}
