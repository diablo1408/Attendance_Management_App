package com.example.attendance_management_app;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity
public class StudentDetails {
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id")
    private   int id;
    @ColumnInfo(name = "full_name")
    private    String fullName;
    @ColumnInfo()
    private   Boolean isPresent;
    String  year;
    @ColumnInfo
    String  section;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Boolean getIsPresent() {
        return isPresent;
    }

    public void setIsPresent(Boolean isPresent) {
        this.isPresent = isPresent;
    }
}
