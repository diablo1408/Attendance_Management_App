package com.example.attendance_management_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddClassActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_class);
    }
}
