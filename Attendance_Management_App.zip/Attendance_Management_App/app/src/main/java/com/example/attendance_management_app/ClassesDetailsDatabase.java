package com.example.attendance_management_app;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {ClassDetails.class,StudentDetails.class},version = 1)
public abstract class ClassesDetailsDatabase extends RoomDatabase {
    public abstract ClassDetailsDao classDetailsDao();

    private static volatile ClassesDetailsDatabase INSTANCE;

    static ClassesDetailsDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (ClassesDetailsDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            ClassesDetailsDatabase.class, "classDetails_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
