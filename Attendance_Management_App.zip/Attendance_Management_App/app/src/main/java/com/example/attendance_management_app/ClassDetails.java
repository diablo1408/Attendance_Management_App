package com.example.attendance_management_app;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.util.ArrayList;

import static androidx.room.ForeignKey.CASCADE;

@Entity(tableName = "ClassDetails")
public class ClassDetails {

    @ColumnInfo(name = "classSection")
    private    String classSection;
    @PrimaryKey @ColumnInfo(name = "subject") @NonNull
    private    String subject;
    @ColumnInfo(name = "course")
    private    String course;
    @ColumnInfo(name = "facultyName")
    private    String  facultyName;
    @ColumnInfo(name = "year")
    private    int year;
    @ColumnInfo(name = "NoOfStudents")
    private     int NoOfStudents;

    public ClassDetails(String classSection, @NonNull String subject, String course, String facultyName, int year, int NoOfStudents) {
        this.classSection = classSection;
        this.subject = subject;
        this.course = course;
        this.facultyName = facultyName;
        this.year = year;
        this.NoOfStudents = NoOfStudents;
    }

    public String getClassSection() {
        return classSection;
    }

    public void setClassSection(String classSection) {
        this.classSection = classSection;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getNoOfStudents() {
        return NoOfStudents;
    }

    public void setNoOfStudents(int noOfStudents) {
        NoOfStudents = noOfStudents;
    }
    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }


}
